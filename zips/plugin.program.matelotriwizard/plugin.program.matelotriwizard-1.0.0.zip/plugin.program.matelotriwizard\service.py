"""Matelotri Service — Limpieza auto + skin + check updates."""
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import os
import json

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ICON = os.path.join(ADDON_PATH, 'icon.png')

HOME = xbmcvfs.translatePath('special://home/')
TEMP = xbmcvfs.translatePath('special://temp/')
USERDATA = xbmcvfs.translatePath('special://userdata/')
PACKAGES = os.path.join(HOME, 'addons', 'packages')
ADDONS = os.path.join(HOME, 'addons')

SKIN_ID = "skin.blackeagle.terror"
PASSWORD = "cabel1n3"

# URL del builds.txt remoto para chequear actualizaciones
BUILDS_URL = "https://actualizarcabel2-prog.github.io/repository.matelotri/builds.txt"
# Archivo local donde guardamos la version instalada
WIZARD_DATA = os.path.join(USERDATA, 'addon_data', 'plugin.program.matelotriwizard')
LOCAL_VERSION_FILE = os.path.join(WIZARD_DATA, 'build_version.txt')
LOGIN_FILE = os.path.join(WIZARD_DATA, 'login_ok.txt')

# Addons que SIEMPRE deben estar habilitados
ESSENTIAL_ADDONS = [
    'repository.matelotri',
    'plugin.program.matelotriwizard',
]


def log(msg):
    xbmc.log('[Matelotri Service] {}'.format(msg), xbmc.LOGINFO)


def clean_on_boot():
    """Limpia solo cache y paquetes, NO addon_data."""
    cleaned = 0
    cache_dirs = [
        PACKAGES,
        os.path.join(HOME, 'cache'),
        TEMP,
    ]
    for d in cache_dirs:
        if os.path.exists(d):
            for f in os.listdir(d):
                try:
                    fp = os.path.join(d, f)
                    if os.path.isfile(fp):
                        os.remove(fp)
                        cleaned += 1
                except:
                    pass
    return cleaned


def ensure_essential_addons():
    """Fuerza la habilitacion del repo y wizard. Recrea repo si falta."""
    # Si el repo no existe fisicamente, crearlo
    repo_path = os.path.join(ADDONS, 'repository.matelotri')
    if not os.path.exists(repo_path):
        log("Repo no existe, creando...")
        os.makedirs(repo_path)
        # Copiar addon.xml desde el wizard (lo tenemos embebido)
        addon_xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="repository.matelotri" name="Matelotri Repository" version="1.0.0" provider-name="Agustin">
    <extension point="xbmc.addon.repository" name="Matelotri Repository">
        <dir>
            <info compressed="false">https://actualizarcabel2-prog.github.io/repository.matelotri/addons.xml</info>
            <checksum>https://actualizarcabel2-prog.github.io/repository.matelotri/addons.xml.md5</checksum>
            <datadir zip="true">https://actualizarcabel2-prog.github.io/repository.matelotri/</datadir>
        </dir>
    </extension>
    <extension point="xbmc.addon.metadata">
        <platform>all</platform>
        <summary lang="es_ES">Repositorio Oficial de Matelotri</summary>
    </extension>
</addon>'''
        with open(os.path.join(repo_path, 'addon.xml'), 'w') as f:
            f.write(addon_xml)
        log("Repo creado en {}".format(repo_path))

    for addon_id in ESSENTIAL_ADDONS:
        addon_path = os.path.join(ADDONS, addon_id)
        if os.path.exists(addon_path):
            # Instalar addon en Kodi si no lo conoce
            xbmc.executeJSONRPC(
                '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
                '"params":{{"addonid":"{}","enabled":true}},"id":1}}'.format(addon_id)
            )
            log("Addon {} habilitado".format(addon_id))


def enable_addons():
    """Habilita addons instalados que no esten en la DB."""
    if not os.path.exists(ADDONS):
        return 0

    enabled = 0
    for addon_name in os.listdir(ADDONS):
        addon_xml = os.path.join(ADDONS, addon_name, 'addon.xml')
        if os.path.exists(addon_xml):
            result = xbmc.executeJSONRPC(
                '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
                '"params":{{"addonid":"{}","enabled":true}},"id":1}}'.format(addon_name)
            )
            try:
                r = json.loads(result)
                if 'result' in r and r['result'] == 'OK':
                    enabled += 1
            except:
                pass

    if enabled > 0:
        log("Habilitados {} addons".format(enabled))
    return enabled


def check_skin():
    """Si el skin Arctic Zephyr esta instalado pero no activo, activarlo."""
    skin_path = os.path.join(ADDONS, SKIN_ID)
    current_skin = xbmc.getSkinDir()

    if os.path.exists(skin_path) and current_skin != SKIN_ID:
        log("Skin {} instalado pero no activo (actual: {})".format(SKIN_ID, current_skin))
        xbmc.executeJSONRPC(
            '{{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
            '"params":{{"setting":"lookandfeel.skin","value":"{}"}},"id":1}}'.format(SKIN_ID)
        )
        log("Skin {} activado".format(SKIN_ID))


def set_language_spanish():
    """Fuerza idioma a Espanol Espana."""
    current = xbmc.executeJSONRPC(
        '{"jsonrpc":"2.0","method":"Settings.GetSettingValue",'
        '"params":{"setting":"locale.language"},"id":1}')
    try:
        lang = json.loads(current).get('result', {}).get('value', '')
    except:
        lang = ''

    if lang != 'resource.language.es_es':
        log("Idioma actual: {} -> cambiando a es_ES".format(lang))
        xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
            '"params":{"setting":"locale.language","value":"resource.language.es_es"},"id":1}')
        log("Idioma cambiado a es_ES")


def check_login():
    """Pide usuario, contrasena y telefono al primer inicio."""
    # Si ya hizo login, no pedir otra vez
    if os.path.exists(LOGIN_FILE):
        return True

    dialog = xbmcgui.Dialog()

    # Pedir usuario
    usuario = dialog.input(
        "[COLOR gold]Matelotri[/COLOR] - Usuario",
        type=xbmcgui.INPUT_ALPHANUM)
    if not usuario:
        dialog.ok("[COLOR gold]Matelotri[/COLOR]",
            "Debes introducir un usuario.\nKodi se cerrara.")
        xbmc.executebuiltin('Quit')
        return False

    # Pedir contrasena
    password = dialog.input(
        "[COLOR gold]Matelotri[/COLOR] - Contrasena",
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if password != PASSWORD:
        dialog.ok("[COLOR tomato]Error[/COLOR]",
            "Contrasena incorrecta.\nKodi se cerrara.")
        xbmc.executebuiltin('Quit')
        return False

    # Pedir telefono
    telefono = dialog.input(
        "[COLOR gold]Matelotri[/COLOR] - Telefono",
        type=xbmcgui.INPUT_ALPHANUM)
    if not telefono:
        dialog.ok("[COLOR gold]Matelotri[/COLOR]",
            "Debes introducir un telefono.\nKodi se cerrara.")
        xbmc.executebuiltin('Quit')
        return False

    # Guardar login
    if not os.path.exists(WIZARD_DATA):
        os.makedirs(WIZARD_DATA)
    with open(LOGIN_FILE, 'w') as f:
        f.write('usuario={}\ntelefono={}'.format(usuario, telefono))
    log("Login OK: {} / {}".format(usuario, telefono))

    dialog.ok("[COLOR gold]Bienvenido a Matelotri[/COLOR]",
        "Usuario: {}\n\nDisfruta del cine en casa!".format(usuario))
    return True


def get_local_build_version():
    """Lee la version de build instalada localmente."""
    if os.path.exists(LOCAL_VERSION_FILE):
        try:
            with open(LOCAL_VERSION_FILE, 'r') as f:
                return f.read().strip()
        except:
            pass
    return "0.0.0"


def save_local_build_version(version):
    """Guarda la version de build instalada."""
    vdir = os.path.dirname(LOCAL_VERSION_FILE)
    if not os.path.exists(vdir):
        os.makedirs(vdir)
    with open(LOCAL_VERSION_FILE, 'w') as f:
        f.write(version)


def get_remote_build_info():
    """Lee builds.txt remoto y devuelve (name, version)."""
    try:
        from urllib.request import urlopen, Request
        req = Request(BUILDS_URL, headers={'User-Agent': 'Kodi/21'})
        resp = urlopen(req, timeout=15)
        data = resp.read().decode('utf-8')
        info = {}
        for line in data.strip().splitlines():
            if '=' in line:
                key, val = line.split('=', 1)
                info[key.strip()] = val.strip().strip('"')
        return info.get('name', 'Matelotri'), info.get('version', '0.0.0')
    except Exception as e:
        log("Error leyendo builds.txt: {}".format(e))
        return None, None


def check_build_update():
    """Comprueba si hay nueva version de build disponible."""
    local_ver = get_local_build_version()
    name, remote_ver = get_remote_build_info()

    if not remote_ver:
        log("No se pudo comprobar actualizaciones")
        return

    log("Build local: {} | Remoto: {}".format(local_ver, remote_ver))

    if remote_ver > local_ver and local_ver != "0.0.0":
        # Esperar a que no haya reproduccion activa
        player = xbmc.Player()
        wait_count = 0
        while player.isPlaying() and wait_count < 360:
            log("Reproductor activo, esperando para actualizar...")
            xbmc.sleep(10000)  # 10 seg
            wait_count += 1
        
        # Hay nueva version!
        dialog = xbmcgui.Dialog()
        if dialog.yesno(
            "[COLOR gold]Matelotri - Actualizacion[/COLOR]",
            "[B]Nueva version disponible![/B]\n\n"
            "Build actual: v{}\n"
            "Nueva version: v{}\n\n"
            "Deseas actualizar ahora?".format(local_ver, remote_ver)):
            # Lanzar la instalacion de build
            xbmc.executebuiltin('RunPlugin(plugin://plugin.program.matelotriwizard/?action=install_build)')
    elif local_ver == "0.0.0":
        # Primera vez - guardar version actual
        save_local_build_version(remote_ver)
        log("Primera ejecucion - version guardada: {}".format(remote_ver))


if __name__ == '__main__':
    monitor = xbmc.Monitor()

    # Esperar a que Kodi este listo
    xbmc.sleep(8000)

    if not monitor.abortRequested():
        # 1. Limpieza (solo cache, NO data)
        log("Limpieza automatica...")
        n = clean_on_boot()
        if n > 0:
            xbmcgui.Dialog().notification(
                "[COLOR gold]Matelotri[/COLOR]",
                "{} archivos cache limpiados".format(n), ICON, 3000)

        # 2. Forzar habilitacion de repo y wizard
        xbmc.sleep(2000)
        ensure_essential_addons()

        # 3. Habilitar otros addons
        xbmc.sleep(2000)
        enable_addons()

        # 4. Idioma espanol
        xbmc.sleep(2000)
        set_language_spanish()

        # 5. Verificar skin
        xbmc.sleep(2000)
        check_skin()

        # 6. Login obligatorio
        xbmc.sleep(3000)
        if not check_login():
            pass  # Kodi se cierra si falla

        # 7. Mostrar version de build
        xbmc.sleep(2000)
        build_ver = get_local_build_version()
        xbmcgui.Dialog().notification(
            "[COLOR gold]Matelotri Cinema[/COLOR]",
            "Build v{}".format(build_ver), ICON, 5000)

        # 8. Forzar actualizacion de repos y addons
        xbmc.sleep(3000)
        log("Forzando actualizacion de repositorios y addons...")
        # Activar updates automaticos en Kodi
        xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
            '"params":{"setting":"general.addonupdates","value":0},"id":1}')
        # Refrescar repos
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.sleep(15000)
        # Actualizar addons locales
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(5000)
        # Instalar TODAS las actualizaciones pendientes
        xbmc.executebuiltin('InstallAddonUpdates(true)')
        log("Actualizacion de repos/addons completada")

        # 9. Comprobar actualizaciones de build
        xbmc.sleep(5000)
        check_build_update()

    while not monitor.abortRequested():
        if monitor.waitForAbort(300):
            break

