"""Matelotri Wizard v3.0 — Build con Emby Cinema + IPTV preconfigurado."""
import sys
import os
import json
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import xbmc

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.png')
MEDIA = os.path.join(ADDON_PATH, 'resources', 'media')

HOME = xbmcvfs.translatePath('special://home/')
USERDATA = xbmcvfs.translatePath('special://userdata/')
PACKAGES = os.path.join(HOME, 'addons', 'packages')
TEMP = xbmcvfs.translatePath('special://temp/')

BUILD_NAME = "Matelotri Cinema"
SKIN_ID = "skin.matelotri"
TUNNEL_URL = "https://pump-iowa-train-bizrate.trycloudflare.com"
TOTAL_PARTS = 1
BASE_URL = TUNNEL_URL + "/repo/MatelotriBuild-1.0.0.zip"
BUILD_PASSWORD = "cabel1n3"

# Emby + IPTV config
EMBY_REPO_URL = "http://kodi.emby.media/repository.emby.kodi-1.0.8.zip"
EMBY_SERVER = "http://209.38.230.244:8096"
EMBY_USER = "sugus"
EMBY_PASS = "cabel1n3"
IPTV_M3U = "https://www.tdtchannels.com/lists/tv.m3u8"
IPTV_EPG = "https://www.tdtchannels.com/epg/TV.xml"

# Addons que NO se deben tocar durante la instalacion
PROTECTED_ADDONS = [
    'plugin.program.matelotriwizard',
]
# Archivos de userdata que NO se deben sobreescribir
PROTECTED_USERDATA = [
    'sources.xml',
    'Database/',
    'addon_data/plugin.program.matelotriwizard/',
]


def add_item(handle, label, action, icon_name, desc=""):
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': os.path.join(MEDIA, icon_name), 'thumb': os.path.join(MEDIA, icon_name), 'fanart': FANART})
    if desc:
        li.setInfo('video', {'plot': desc})
    url = "plugin://{}/?action={}".format(ADDON_ID, action)
    xbmcplugin.addDirectoryItem(handle, url, li, False)


def add_sep(handle, text):
    li = xbmcgui.ListItem("[COLOR gold]━━━ {} ━━━[/COLOR]".format(text))
    li.setArt({'icon': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(handle, "", li, False)


def menu(handle):
    add_sep(handle, "🎬  M A T E L O T R I  🎬")
    add_item(handle, "[COLOR gold][B]📥 Instalar Build Completa[/B][/COLOR]", "install_build", "builds.png",
        "Build completa con Emby Cinema, IPTV, cine, series. Protegida con password.")
    add_item(handle, "[COLOR lime][B]🔗 Configurar Emby[/B][/COLOR]", "setup_emby", "install.png",
        "Instala y configura Emby for Kodi con el servidor Matelotri Cinema.")
    add_item(handle, "[COLOR cyan][B]📺 Configurar IPTV[/B][/COLOR]", "setup_iptv", "install.png",
        "Configura IPTV Simple Client con canales TDT Espana.")
    add_item(handle, "[COLOR gold][B]🎬 Activar Skin Matelotri[/B][/COLOR]", "activate_skin", "install.png",
        "Activa el skin premium Matelotri.")
    add_sep(handle, "🔧  MANTENIMIENTO")
    add_item(handle, "[COLOR deepskyblue]🧹 Limpieza Profunda[/COLOR]", "deep_clean", "clean.png",
        "Cache + paquetes + temporales.")
    add_item(handle, "[COLOR deepskyblue]🗑️ Solo Cache[/COLOR]", "clean_cache", "maintenance.png", "")
    add_item(handle, "[COLOR deepskyblue]📦 Solo Paquetes[/COLOR]", "clean_packages", "settings.png", "")
    add_sep(handle, "⚡  SISTEMA")
    add_item(handle, "[COLOR tomato]🔄 Reiniciar Limpio[/COLOR]", "restart_clean", "power.png", "Limpia + cierra.")
    add_item(handle, "[COLOR tomato]⚡ Forzar Cierre[/COLOR]", "force_close", "power.png", "")
    add_item(handle, "[COLOR white]📋 Info[/COLOR]", "about", "info.png", "v3.0")
    xbmcplugin.endOfDirectory(handle)


def _download(url, dest, progress, label):
    from urllib.request import urlopen, Request
    req = Request(url, headers={'User-Agent': 'Kodi/21'})
    resp = urlopen(req, timeout=300)
    total = int(resp.headers.get('Content-Length', 0))
    got = 0
    with open(dest, 'wb') as f:
        while True:
            if progress.iscanceled():
                return False
            buf = resp.read(65536)
            if not buf:
                break
            f.write(buf)
            got += len(buf)
            if total > 0:
                pct = int(got * 100 / total)
                progress.update(pct, "{} - {:.1f}/{:.1f} MB".format(label, got/1048576, total/1048576))
    return True


def _is_protected(name):
    """Comprueba si un archivo pertenece a un addon protegido o userdata protegido."""
    # Proteger addons del wizard
    if name.startswith('addons/'):
        for pa in PROTECTED_ADDONS:
            if name.startswith('addons/' + pa + '/'):
                return True
    # Proteger sources.xml, Database, y addon_data del wizard
    if name.startswith('userdata/'):
        rel = name[len('userdata/'):]
        if rel in PROTECTED_USERDATA:
            return True
        for pu in PROTECTED_USERDATA:
            if pu.endswith('/') and rel.startswith(pu):
                return True
    # Proteger addon_data/ directo (sin prefijo userdata/)
    if name.startswith('addon_data/'):
        for pu in PROTECTED_USERDATA:
            if pu.startswith('addon_data/') and name.startswith(pu):
                return True
    return False


def _extract(zip_path, progress, label):
    import zipfile
    with zipfile.ZipFile(zip_path, 'r') as zf:
        names = [n for n in zf.namelist() if not n.endswith('/')]
        total = len(names)
        skipped = 0
        for i, name in enumerate(names):
            # Saltar archivos protegidos
            if _is_protected(name):
                skipped += 1
                if i % 30 == 0:
                    progress.update(int(i*100/total), "{} - {}/{}".format(label, i, total))
                continue

            # CLI 002 structure: addons/, userdata/, media/
            if name.startswith('addons/'):
                dest = os.path.join(HOME, name)
            elif name.startswith('userdata/'):
                # userdata/xxx -> USERDATA/xxx
                rel = name[len('userdata/'):]
                dest = os.path.join(USERDATA, rel)
            elif name.startswith('media/'):
                dest = os.path.join(HOME, name)
            elif name.startswith('addon_data/'):
                dest = os.path.join(USERDATA, name)
            else:
                dest = os.path.join(USERDATA, name)
            dest_dir = os.path.dirname(dest)
            if not os.path.exists(dest_dir):
                os.makedirs(dest_dir)
            if not name.endswith('/'):
                try:
                    data = zf.read(name)
                    with open(dest, 'wb') as out:
                        out.write(data)
                except:
                    pass
            if i % 30 == 0:
                progress.update(int(i*100/total), "{} - {}/{}".format(label, i, total))
    if skipped > 0:
        xbmc.log('[Matelotri] Protegidos {} archivos (repo+wizard+sources)'.format(skipped), xbmc.LOGINFO)
    return True


def install_build():
    dialog = xbmcgui.Dialog()
    
    # Password protection
    pwd = dialog.input("[COLOR gold]Matelotri Cinema[/COLOR]\nIntroduce la clave de instalacion:",
                       type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if pwd != BUILD_PASSWORD:
        dialog.ok("[COLOR red]Error[/COLOR]", "Clave incorrecta.\nContacta con el administrador.")
        return
    
    if not dialog.yesno("[COLOR gold]Matelotri Cinema[/COLOR]",
        "[B]Instalar Build Completa?[/B]\n\n"
        "Se descargara el paquete Matelotri (~25 MB)\n"
        "con skin, addons y configuracion.\n\n"
        "Incluye: Skin Matelotri, Cinema,\n"
        "repositorio y configuracion completa.\n\n"
        "[COLOR tomato]Kodi se cerrara al terminar.[/COLOR]"):
        return

    if not os.path.exists(PACKAGES):
        os.makedirs(PACKAGES)

    progress = xbmcgui.DialogProgress()
    zip_path = os.path.join(PACKAGES, 'MatelotriBuild.zip')

    # Descargar build ZIP
    progress.create("[COLOR gold]Matelotri[/COLOR]", "Descargando Build Matelotri...")
    try:
        ok = _download(BASE_URL, zip_path, progress, "Build Matelotri")
        if not ok:
            progress.close()
            dialog.ok("Matelotri", "Descarga cancelada")
            return
    except Exception as e:
        progress.close()
        dialog.ok("Error", str(e))
        return
    progress.close()

    # Extraer
    progress.create("[COLOR gold]Matelotri[/COLOR]", "Instalando Build Matelotri...")
    try:
        _extract(zip_path, progress, "Build Matelotri")
    except Exception as e:
        progress.close()
        dialog.ok("Error", str(e))
        return
    progress.close()

    # Limpiar zip
    try:
        os.remove(zip_path)
    except:
        pass

    # Guardar version
    ver_dir = os.path.join(USERDATA, 'addon_data', 'plugin.program.matelotriwizard')
    if not os.path.exists(ver_dir):
        os.makedirs(ver_dir)
    with open(os.path.join(ver_dir, 'build_version.txt'), 'w') as f:
        f.write('1.0.0')

    # Forzar habilitacion de todos los addons instalados
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.sleep(2000)
    
    addons_dir = os.path.join(HOME, 'addons')
    if os.path.exists(addons_dir):
        for addon_name in os.listdir(addons_dir):
            addon_xml = os.path.join(addons_dir, addon_name, 'addon.xml')
            if os.path.exists(addon_xml):
                xbmc.executeJSONRPC(
                    '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
                    '"params":{{"addonid":"{}","enabled":true}},"id":1}}'.format(addon_name))
    
    # Forzar skin Matelotri
    xbmc.executeJSONRPC(
        '{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
        '"params":{{"addonid":"{}","enabled":true}},"id":1}}'.format(SKIN_ID))
    xbmc.sleep(1000)
    xbmc.executeJSONRPC(
        '{{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
        '"params":{{"setting":"lookandfeel.skin","value":"{}"}}"id":1}}'.format(SKIN_ID))
    xbmc.sleep(1000)
    xbmc.executebuiltin('SendClick(11)')

    dialog.ok("[COLOR gold]Matelotri Cinema[/COLOR]",
        "[B]Build instalada![/B]\n\n"
        "Skin Matelotri activado.\n"
        "Todos los addons configurados.\n\n"
        "[COLOR gold]Al reabrir: cine en casa! 🎬[/COLOR]")

    xbmc.executebuiltin('Quit')


def activate_skin():
    if not xbmcgui.Dialog().yesno("[COLOR gold]Matelotri[/COLOR]", "Activar Skin Matelotri?"):
        return
    # Primero habilitar el addon
    xbmc.executeJSONRPC(
        '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
        '"params":{"addonid":"' + SKIN_ID + '","enabled":true},"id":1}')
    xbmc.sleep(1000)
    # Luego cambiar skin
    xbmc.executeJSONRPC(
        '{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
        '"params":{"setting":"lookandfeel.skin","value":"' + SKIN_ID + '"},"id":1}')
    xbmc.sleep(2000)
    # Auto-confirmar el cambio
    xbmc.executebuiltin('SendClick(11)')
    xbmcgui.Dialog().ok("[COLOR gold]Matelotri[/COLOR]", "Skin Matelotri activado!")


def deep_clean():
    if not xbmcgui.Dialog().yesno("[COLOR gold]Matelotri[/COLOR]", "Limpieza profunda?"):
        return
    n = _clean(os.path.join(HOME,'cache')) + _clean(PACKAGES) + _clean(TEMP)
    xbmcgui.Dialog().ok("[COLOR gold]Matelotri[/COLOR]", "[B]{} archivos eliminados[/B]".format(n))


def clean_cache():
    n = _clean(os.path.join(HOME,'cache')) + _clean(TEMP)
    xbmcgui.Dialog().notification("[COLOR gold]Matelotri[/COLOR]", "{} eliminados".format(n), ICON, 3000)


def clean_packages():
    n = _clean(PACKAGES)
    xbmcgui.Dialog().notification("[COLOR gold]Matelotri[/COLOR]", "{} paquetes eliminados".format(n), ICON, 3000)


def restart_clean():
    if not xbmcgui.Dialog().yesno("[COLOR gold]Matelotri[/COLOR]", "Limpiar y cerrar?"):
        return
    _clean(os.path.join(HOME,'cache')); _clean(PACKAGES); _clean(TEMP)
    xbmc.sleep(1000)
    xbmc.executebuiltin('Quit')


def force_close():
    if xbmcgui.Dialog().yesno("[COLOR gold]Matelotri[/COLOR]", "Cerrar Kodi?"):
        xbmc.executebuiltin('Quit')


def setup_emby():
    """Install and configure Emby for Kodi manually"""
    dialog = xbmcgui.Dialog()
    progress = xbmcgui.DialogProgress()
    
    # Download Emby repo
    progress.create("[COLOR gold]Matelotri[/COLOR]", "Descargando repositorio Emby...")
    repo_zip = os.path.join(PACKAGES, 'repository.emby.kodi.zip')
    if not os.path.exists(PACKAGES):
        os.makedirs(PACKAGES)
    try:
        ok = _download(EMBY_REPO_URL, repo_zip, progress, "Emby Repo")
        if not ok:
            progress.close()
            return
    except Exception as e:
        progress.close()
        dialog.ok("Error", str(e))
        return
    progress.close()
    
    # Install from zip
    xbmc.executebuiltin('InstallAddon({})'.format(repo_zip))
    xbmc.sleep(3000)
    
    # Configure Emby addon data
    _auto_setup_emby()
    
    dialog.ok("[COLOR gold]Matelotri[/COLOR]",
        "[B]Emby configurado![/B]\n\n"
        "Servidor: {}\n"
        "Usuario: {}\n\n"
        "Reinicia Kodi para completar.".format(EMBY_SERVER, EMBY_USER))


def setup_iptv():
    """Configure IPTV Simple Client"""
    _auto_setup_iptv()
    xbmcgui.Dialog().ok("[COLOR gold]Matelotri[/COLOR]",
        "[B]IPTV configurado![/B]\n\n"
        "M3U: TDTChannels Espana\n"
        "EPG: Guia XML\n\n"
        "Reinicia Kodi para ver los canales.")


def _auto_setup_emby():
    """Auto-configure Emby addon settings"""
    try:
        emby_data = os.path.join(USERDATA, 'addon_data', 'plugin.video.emby')
        if not os.path.exists(emby_data):
            os.makedirs(emby_data)
        
        # Server connection
        servers = {
            "Servers": [{
                "Name": "Matelotri Cinema",
                "Address": EMBY_SERVER,
                "ManualAddress": EMBY_SERVER,
                "LastConnectionMode": 2,
                "DateLastAccessed": "2026-03-27T10:00:00Z"
            }]
        }
        with open(os.path.join(emby_data, 'servers.json'), 'w') as f:
            json.dump(servers, f, indent=2)
        
        # Settings
        settings_xml = '''<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<settings version="2">
    <setting id="server_address">209.38.230.244</setting>
    <setting id="server_port">8096</setting>
    <setting id="server_ssl">false</setting>
    <setting id="username">''' + EMBY_USER + '''</setting>
    <setting id="enableCinemaMode">true</setting>
    <setting id="syncDuringPlayback">true</setting>
    <setting id="syncIndicator">true</setting>
    <setting id="enableContext">true</setting>
    <setting id="kodiCompanion">true</setting>
</settings>'''
        with open(os.path.join(emby_data, 'settings.xml'), 'w') as f:
            f.write(settings_xml)
        
        xbmc.log('[Matelotri] Emby configurado: {}'.format(EMBY_SERVER), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Matelotri] Error configurando Emby: {}'.format(e), xbmc.LOGERROR)


def _auto_setup_iptv():
    """Auto-configure IPTV Simple Client"""
    try:
        iptv_data = os.path.join(USERDATA, 'addon_data', 'pvr.iptvsimple')
        if not os.path.exists(iptv_data):
            os.makedirs(iptv_data)
        
        settings_xml = '''<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<settings version="2">
    <setting id="m3uPathType">1</setting>
    <setting id="m3uUrl">''' + IPTV_M3U + '''</setting>
    <setting id="m3uCache">true</setting>
    <setting id="startNum">1</setting>
    <setting id="m3uRefreshMode">1</setting>
    <setting id="m3uRefreshIntervalMins">120</setting>
    <setting id="epgPathType">1</setting>
    <setting id="epgUrl">''' + IPTV_EPG + '''</setting>
    <setting id="epgCache">true</setting>
    <setting id="epgTimeShift">0</setting>
</settings>'''
        with open(os.path.join(iptv_data, 'settings.xml'), 'w') as f:
            f.write(settings_xml)
        
        xbmc.log('[Matelotri] IPTV configurado: {}'.format(IPTV_M3U), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[Matelotri] Error configurando IPTV: {}'.format(e), xbmc.LOGERROR)


def about():
    xbmcgui.Dialog().ok("[COLOR gold]Matelotri Cinema v3.0[/COLOR]",
        "Build: {} partes\nEmby: {} peliculas\nIPTV: TDT Espana\nSkin: Arctic Zephyr\n\n🎬 Cine en casa".format(TOTAL_PARTS, '1400+'))


def _clean(path):
    n = 0
    if os.path.exists(path):
        for f in os.listdir(path):
            try:
                fp = os.path.join(path, f)
                if os.path.isfile(fp): os.remove(fp); n += 1
            except: pass
    return n


if __name__ == '__main__':
    handle = int(sys.argv[1])
    params = sys.argv[2].lstrip('?')
    if not params:
        menu(handle)
    else:
        a = dict(x.split('=') for x in params.split('&') if '=' in x).get('action','')
        {'install_build':install_build,'setup_emby':setup_emby,'setup_iptv':setup_iptv,
         'activate_skin':activate_skin,'deep_clean':deep_clean,
         'clean_cache':clean_cache,'clean_packages':clean_packages,'restart_clean':restart_clean,
         'force_close':force_close,'about':about}.get(a, lambda:None)()
